The folders Buggy1, Buggy2, Buggy3, Buggy4, and Buggy5 contain the buggy Deck.java files.

The Correct folder contains the correct Deck.java file.


