There is no solution code for Activity 6.
